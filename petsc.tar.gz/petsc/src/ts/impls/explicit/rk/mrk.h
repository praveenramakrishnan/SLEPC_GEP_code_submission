PETSC_INTERN PetscErrorCode TSRKSetMultirate_RK(TS,PetscBool);
PETSC_INTERN PetscErrorCode TSRKGetMultirate_RK(TS,PetscBool*);
